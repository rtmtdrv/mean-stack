import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})

export class HttpService {

  constructor(private _http: HttpClient) { 
    this.getPokemon();
    this.pokemonAbilities();
    this.solarPower();
    this.blaze();
  }
  // getPokemon(){
  //   let bulbasaur = this._http.get('https://pokeapi.co/api/v2/pokemon/1/');
  // }

  getPokemon(){
    let pokemon = this._http.get("https://pokeapi.co/api/v2/pokemon/6");
    pokemon.subscribe((data:any) => {
      console.log("Got our Pokemon!", data);
    })
  };

  pokemonAbilities(){
    let pokemon = this._http.get("https://pokeapi.co/api/v2/pokemon/6/");
    pokemon.subscribe((data:any) => {
      console.log(`${data.name[0].toUpperCase()+data.name.slice(1)}'s abilities are ${data.abilities[0].ability.name} and ${data.abilities[1].ability.name}.`);
    })
  };

  solarPower(){
    let solarPower = this._http.get("https://pokeapi.co/api/v2/ability/94/");
    solarPower.subscribe((data:any) => {
      console.log(`${data.pokemon.length} Pokemon have the ${data.name} ability!`)
    })
  };

  blaze(){
    let blaze = this._http.get("https://pokeapi.co/api/v2/ability/66/");
    blaze.subscribe((data:any) => {
      console.log(`${data.pokemon.length} Pokemon have the ${data.name} ability!`)
    })
  };
}
