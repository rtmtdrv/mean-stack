
const mongoose = require('mongoose');
//const Quote = require('../models/quote.js');